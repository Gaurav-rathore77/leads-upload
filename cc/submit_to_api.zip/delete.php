<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $conn->query("DELETE FROM enquiries WHERE id = $id");
    echo "Entry deleted. <a href='index.php'>Back to Dashboard</a>";
}
?>